/**
 * Created by Classdumper, User Peter Heusch
 * Creation Date: 15.12.2017 07:49:44
 */
package simplePong;

import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public final class SimpleEngine {

    public class Game {

        private Point2D.Float puckPoint;
        private float puckSpeed;
        private float puckAngle;
        private float paddlePosition;
        private long paddleTimestamp;
        private long oldTimestamp;
        private float oldPosition;
        private float speedUp;

        public Game(Point2D.Float polyCenter) {
            // Roughly 8 lines of implementation
            this.puckPoint = polyCenter;
            this.puckSpeed = 1;
            speedUp = 1;
            this.paddlePosition = 165;
            //this.puckSpeed = (oldPosition - paddlePosition) / (oldTimestamp - paddleTimestamp);

        }
    }

    public class Court {

        private final Point2D.Float polyCenter;
        private final Point2D.Float rectCenter;
        private final Path2D.Float gamePath;
        private final Rectangle2D.Float drawRectangle;

        private Court() {

            // Roughly 18 lines of implementation
            this.polyCenter = new Point2D.Float(200, 200);
            Game g = new Game(polyCenter);

            this.drawRectangle = new Rectangle2D.Float(0, 0, 200, 200);
            this.rectCenter = new Point2D.Float(drawRectangle.width / 2, drawRectangle.height / 2);
            this.gamePath = new Path2D.Float(drawRectangle);
            System.out.println(gamePath.getBounds2D());

        }
    }

    public static final int BALLSIZE = 10;
    public static final int RACKETQUOTE = 70;
    public static final int SQUARE_SIZE = 400;
    public static final int BORDER = 4;
    public static final int LINEWIDTH = 2;
    public static final float PI = 3.141593f;
    public static final int RACKETSPEED = 2;
    public static boolean first = true;
    public int velX = 2;
    public int velY = 1;
    private SimpleEngine.Court court;
    private SimpleEngine.Game game;

    public SimpleEngine() {
        // Roughly 2 lines of implementation
        this.court = new Court();
        this.game = new Game(this.court.polyCenter);
    }

    private float sin(float angle) {
        // Roughly 1 lines of implementation
        return (float) Math.sin((2 * PI / 360) * angle);
    }

    private float cos(float angle) {
        // Roughly 1 lines of implementation
        return (float) Math.cos((2 * PI / 360) * angle);
    }

    private float atan2(float x, float y) {
        // Roughly 1 lines of implementation
        return (float) Math.atan2(x, y);
    }

    private float sqrt(float x) {
        // Roughly 1 lines of implementation
        return (float) Math.sqrt(x);
    }

    private float random() {
        // Roughly 1 lines of implementation
        return (float) Math.random();
    }

    private float round(float angle) {
        // Roughly 1 lines of implementation
        return Math.round(angle);
    }

    private float toDegrees(float angle) {
        // Roughly 1 lines of implementation
        return (float) (360 / 2 * PI) * angle;
    }

    public void speedUp(float speedUp) {
        // Roughly 1 lines of implementation
        game.puckSpeed = game.puckSpeed + game.speedUp;
    }

    public void step(int id) {
        // Roughly 45 lines of implementation
//        if (getPuck().x < getBorderPoint(getPuck().x).x) {
//            velX = -velX;
//        }
//        // top / down walls //scores
//        if (getPuck().y < 0) {
//            velY = -velY;
//        }
//
//        if (getPuck().y + BALLSIZE > 0) {
//            velY = -velY;
//        }
        // bottom pad
//        if (ballY + ballSize >= height - padH - inset && velY > 0) {
//            if (ballX + ballSize >= bottomPadX && ballX <= bottomPadX + padW) {
//                velY = -velY;
//            }
//        }
        if (first) {
            game.puckPoint.x += Math.random() * 2;
            game.puckPoint.y += Math.random() * 2;
            first = false;
        }

        int minX = getPolygon().getBounds().x;
        int minY = getPolygon().getBounds().y;
        int height = getPolygon().getBounds().height + minX;
        int width = getPolygon().getBounds().width + minY;
        Point rightU = new Point(width, height);
        Point midO = new Point(height / 2, minY);
        Point leftU = new Point(minX, height);
        Line2D left = new Line2D.Float(midO, leftU);
        Line2D right = new Line2D.Float(midO, rightU);
//         System.out.println(getPolygon().getBounds());

        //
        float puckY = getPuck().y;
        float puckX = getPuck().x;
        if (puckY + BALLSIZE >= getRacket()[0].y) {
            if (puckX + BALLSIZE >= getRacket()[0].x && puckX <= getRacket()[0].x + RACKETQUOTE) {
                velY = -velY;
            }
        }

        if (puckY < 0) {
            velY = -velY;
        } else if (puckY + BALLSIZE >= getDrawRectangle().height) {
//            JFrame frame = new JFrame();
//            JOptionPane.showMessageDialog(frame, "You failed");
        }

        Line2D puckLine = new Line2D.Float(getPuck(), new Point.Float(puckX + velX + BALLSIZE, puckY + velY + BALLSIZE));
        if (puckLine.intersectsLine(left)) {
            System.out.println(atan2((float) puckLine.getX1(), (float) puckLine.getY1()));
            System.out.println(atan2((float) puckLine.getY1(), (float) puckLine.getX1()));
            double f = atan2((float) puckLine.getX1(), (float) puckLine.getY1());
            System.out.println(f + " fl");
            if (f <= 0.90) {
                velX = -velX;
                velY = velY;
            } else if (0.90 < f && f <= 1.80) {
                velX = +velX;
                velY = -velY;
            } else if (1.80 < f && f <= 2.70) {
                velX = -velX;
                velY = velY;
            } else if (2.70 < f && f <= 3.60) {
                velX = -velX;
                velY = velY;
            }
        } else if (puckLine.intersectsLine(right)) {
            //System.out.println(atan2((float) puckLine.getX1(), (float) right.getY1()));
            System.out.println(atan2((float) puckLine.getY1(), (float) puckLine.getX1()));
            double f = atan2((float) puckLine.getX1(), (float) puckLine.getY1());
            System.out.println(f + " fr");
            if (f <= 0.90) {
                velX = -velX;
                velY = velY;
            } else if (0.90 < f && f <= 1.80) {
                velX = +velX;
                velY = -velY;
            } else if (1.80 < f && f <= 2.70) {
                velX = -velX;
                velY = velY;
            } else if (2.70 < f && f <= 3.60) {
                velX = -velX;
                velY = velY;
            }
        }

        //change Puck in Game
        game.puckPoint.x += velX;
        game.puckPoint.y += velY;

        Point[] racket = getRacket();

        //racket um Racketspeed größer da sonst aus dem Fenster
        Line2D racketline = new Line2D.Float(new Point(racket[0].x - RACKETSPEED, racket[0].y), new Point(racket[racket.length - 1].x + RACKETSPEED, racket[racket.length - 1].y));
        //Polygon Linien

        //Rectangle r = new Rectangle(racket[0].x, racket[0].y, RACKETQUOTE , 10);
//                 if(getPolygon().intersects(r))
        if (id == KeyEvent.VK_RIGHT) {
//            if(game.paddlePosition < this.getBorderPoint(350).x) {
            if (!racketline.intersectsLine(right)) {
                game.paddlePosition += RACKETSPEED;
            }
//            }
        } else if (id == KeyEvent.VK_LEFT) {
            if (!racketline.intersectsLine(left)) {
                game.paddlePosition -= RACKETSPEED;
            }
        }
    }

    public Point[] getRacket() {
        // Roughly 12 lines of implementation
        int racketplace = 380;          //y-Koordinate
        Point[] p2 = new Point[70];   // use Racketquote
        for (int i = 0; i < p2.length; i++) {
            p2[i] = new Point((int) game.paddlePosition + i, racketplace);   //need Bound for x-Koordinate
        }
        return p2;
    }

    private Point getNormal(Point lineStart, Point lineEnd) {
        // Roughly 1 lines of implementation
        return new Point((lineStart.x + lineEnd.x) / 2, lineStart.y);
    }

    Polygon getPolygon() {
        // Roughly 7 lines of implementation
        Polygon poly = new Polygon();
        poly.addPoint(400 / 2, BORDER);
        poly.addPoint(BORDER, 400 - BORDER);
        poly.addPoint(400 - BORDER, 400 - BORDER);
        return poly;
    }

    public Point.Float getPuck() {
        // Roughly 1 lines of implementation
        return game.puckPoint;
    }

    public Point[] getBorderLine(int i) {
        // Roughly 2 lines of implementation
//        Point[] p = getPolygon();
//        return new Point[i]; 
        Polygon p = getPolygon();
        throw new UnsupportedOperationException("Not yet implemented");
    }

    private Point2D.Float getIntersection(Line2D.Float l, Line2D.Float m) {
        // Roughly 2 lines of implementation
        double d = (l.x1 - l.x2) * (m.y1 - m.y2) - (l.y1 - l.y2) * (m.x1 - m.x2);
        double xi = ((m.x1 - m.x2) * (l.x1 * l.y2 - l.y1 * l.x2) - (l.x1 - l.x2) * (m.x1 * m.y2 - m.y1 * m.x2)) / d;
        double yi = ((m.y1 - m.y2) * (l.x1 * l.y2 - l.y1 * l.x2) - (l.y1 - l.y2) * (m.x1 * m.y2 - m.y1 * m.x2)) / d;
        return new Point2D.Float((float) xi, (float) yi);

    }

    private float getAngle(Line2D.Float l, Line2D.Float m) {
        // Roughly 1 lines of implementation
        return atan2(l.x1, m.y1);
    }

    public void setPosition(float position) {
        // Roughly 3 lines of implementation
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Point getBorderPoint(int i) {
        // Roughly 5 lines of implementation

        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Rectangle getDrawRectangle() {
        // Roughly 1 lines of implementation
        return new Rectangle(SQUARE_SIZE, SQUARE_SIZE);
    }

    public Point getRectCenter() {
        // Roughly 1 lines of implementation
        return new Point((int) court.rectCenter.x, (int) court.rectCenter.y);
    }
}
